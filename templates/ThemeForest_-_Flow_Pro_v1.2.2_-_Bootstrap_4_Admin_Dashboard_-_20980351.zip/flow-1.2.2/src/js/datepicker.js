$('.datepicker').datepicker({   orientation: 'bottom left'});

$('.input-group.date').datepicker({  orientation: 'auto' })

$('.input-daterange input').datepicker({
  orientation: 'auto'
});